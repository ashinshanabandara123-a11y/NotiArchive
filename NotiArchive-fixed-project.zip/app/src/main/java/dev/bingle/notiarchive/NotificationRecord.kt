package dev.bingle.notiarchive

data class NotificationRecord(
    val id: Long,
    val key: String,
    val notificationId: Int,
    val packageName: String,
    val title: String,
    val content: String,
    val bigText: String,
    val postedAt: Long,
    val ongoing: Boolean,
    val icon: ByteArray?,
    val picture: ByteArray?
)
