package dev.bingle.notiarchive

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteException

class ArchiveDb(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    "notiarchive.db",
    null,
    DATABASE_VERSION
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE notification (
                _id INTEGER PRIMARY KEY AUTOINCREMENT,
                notification_key TEXT NOT NULL UNIQUE,
                notification_id INTEGER NOT NULL DEFAULT 0,
                package_name TEXT NOT NULL,
                title TEXT NOT NULL DEFAULT '',
                content_text TEXT NOT NULL DEFAULT '',
                big_text TEXT NOT NULL DEFAULT '',
                posted_at INTEGER NOT NULL,
                ongoing INTEGER NOT NULL DEFAULT 0,
                icon BLOB,
                picture BLOB
            )"""
        )
        db.execSQL(
            """CREATE VIRTUAL TABLE notification_fts USING fts4(
                title, content_text, big_text, package_name,
                content='notification', tokenize=unicode61
            )"""
        )
        db.execSQL(
            """CREATE TRIGGER notification_ai AFTER INSERT ON notification BEGIN
                INSERT INTO notification_fts(docid,title,content_text,big_text,package_name)
                VALUES(new._id,new.title,new.content_text,new.big_text,new.package_name);
            END"""
        )
        db.execSQL(
            """CREATE TRIGGER notification_ad AFTER DELETE ON notification BEGIN
                DELETE FROM notification_fts WHERE docid=old._id;
            END"""
        )
        db.execSQL(
            """CREATE TRIGGER notification_au AFTER UPDATE ON notification BEGIN
                DELETE FROM notification_fts WHERE docid=old._id;
                INSERT INTO notification_fts(docid,title,content_text,big_text,package_name)
                VALUES(new._id,new.title,new.content_text,new.big_text,new.package_name);
            END"""
        )
        db.execSQL("CREATE INDEX notification_time_idx ON notification(posted_at DESC)")
        db.execSQL("CREATE INDEX notification_package_idx ON notification(package_name)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Add forward-only schema migrations here when DATABASE_VERSION changes.
    }

    @Synchronized
    fun upsert(record: NotificationRecord) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("notification_id", record.notificationId)
            put("package_name", record.packageName)
            put("title", record.title)
            put("content_text", record.content)
            put("big_text", record.bigText)
            put("posted_at", record.postedAt)
            put("ongoing", if (record.ongoing) 1 else 0)
            record.icon?.let { put("icon", it) }
            record.picture?.let { put("picture", it) }
        }

        db.beginTransaction()
        try {
            val updated = db.update(
                "notification",
                values,
                "notification_key = ?",
                arrayOf(record.key)
            )
            if (updated == 0) {
                values.put("notification_key", record.key)
                db.insertOrThrow("notification", null, values)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun query(
        search: String = "",
        excludedPackages: Set<String> = emptySet(),
        limit: Int = 300
    ): List<NotificationRecord> {
        val db = readableDatabase
        val safeLimit = limit.coerceIn(1, 5000)
        val excludedSql = if (excludedPackages.isEmpty()) {
            ""
        } else {
            " AND n.package_name NOT IN (${excludedPackages.joinToString(",") { "?" }})"
        }

        val columns =
            "n._id,n.notification_key,n.notification_id,n.package_name,n.title," +
                "n.content_text,n.big_text,n.posted_at,n.ongoing,n.icon,n.picture"

        if (search.isNotBlank()) {
            val tokens = search.trim()
                .split(Regex("\\s+"))
                .filter { it.isNotBlank() }

            if (tokens.isNotEmpty()) {
                val ftsQuery = tokens.joinToString(" AND ") { token ->
                    "\"" + token.replace("\"", "\"\"") + "\"*"
                }
                try {
                    val args = mutableListOf(ftsQuery)
                    args.addAll(excludedPackages)
                    args.add(safeLimit.toString())

                    val cursor = db.rawQuery(
                        "SELECT $columns " +
                            "FROM notification n " +
                            "JOIN notification_fts f ON f.docid = n._id " +
                            "WHERE notification_fts MATCH ?$excludedSql " +
                            "ORDER BY n.posted_at DESC LIMIT ?",
                        args.toTypedArray()
                    )
                    return cursor.use(::readRecords)
                } catch (_: SQLiteException) {
                    // Fall through to parameterized LIKE search for unsupported FTS syntax.
                }
            }
        }

        val args = mutableListOf<String>()
        val where = if (search.isBlank()) {
            "1=1"
        } else {
            val like = "%${search.trim()}%"
            args.addAll(listOf(like, like, like, like))
            "(n.title LIKE ? OR n.content_text LIKE ? OR " +
                "n.big_text LIKE ? OR n.package_name LIKE ?)"
        }
        args.addAll(excludedPackages)
        args.add(safeLimit.toString())

        val cursor = db.rawQuery(
            "SELECT $columns FROM notification n " +
                "WHERE $where$excludedSql " +
                "ORDER BY n.posted_at DESC LIMIT ?",
            args.toTypedArray()
        )
        return cursor.use(::readRecords)
    }

    fun deleteOlderThan(cutoffMillis: Long): Int =
        writableDatabase.delete(
            "notification",
            "posted_at < ?",
            arrayOf(cutoffMillis.toString())
        )

    fun deleteById(id: Long): Int =
        writableDatabase.delete("notification", "_id = ?", arrayOf(id.toString()))

    fun deleteAll(): Int = writableDatabase.delete("notification", null, null)

    fun count(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM notification", null).use {
            return if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    private fun readRecords(cursor: Cursor): List<NotificationRecord> {
        val records = ArrayList<NotificationRecord>(cursor.count)
        while (cursor.moveToNext()) {
            records += NotificationRecord(
                id = cursor.getLong(0),
                key = cursor.getString(1) ?: "",
                notificationId = cursor.getInt(2),
                packageName = cursor.getString(3) ?: "",
                title = cursor.getString(4) ?: "",
                content = cursor.getString(5) ?: "",
                bigText = cursor.getString(6) ?: "",
                postedAt = cursor.getLong(7),
                ongoing = cursor.getInt(8) != 0,
                icon = if (cursor.isNull(9)) null else cursor.getBlob(9),
                picture = if (cursor.isNull(10)) null else cursor.getBlob(10)
            )
        }
        return records
    }

    companion object {
        private const val DATABASE_VERSION = 1
    }
}
