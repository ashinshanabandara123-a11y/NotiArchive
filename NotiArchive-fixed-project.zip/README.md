# NotiArchive

An independent Android notification-history application. It archives notifications locally through Android's `NotificationListenerService`.

## Features

- Notification capture using Android notification-listener access.
- Local SQLite storage with notification-key upsert behavior.
- SQLite FTS4 full-text search, with a parameterized `LIKE` fallback.
- Package and keyword exclusions.
- Configurable retention: 7, 30, 90, 180, 365 days, or forever.
- Notification title, text, expanded text, package, timestamp, ongoing state, icon and picture storage.
- Searchable history, detail view, manual deletion and clear-history action.

## Requirements

- Android Studio Ladybug or newer.
- JDK 17.
- Android SDK Platform 35 and Build Tools 35.0.0.
- Android Gradle Plugin 8.7.3.
- Gradle 8.9.

## Build in Android Studio

1. Open the directory containing `settings.gradle.kts`.
2. Allow Gradle sync to finish.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The debug APK is written to:

`app/build/outputs/apk/debug/app-debug.apk`

## Build with GitHub Actions

The repository includes `.github/workflows/build.yml`.

1. Keep the existing workflow at `.github/workflows/build.yml` in your repository. If needed, replace it with the workflow included in this ZIP.
2. Upload this ZIP file to the root of your GitHub repository as a normal file, or extract its contents into the repository root. The workflow supports either layout.
3. Push to the `main` branch, or run **Build NotiArchive APK** from the Actions tab using **Run workflow**.
4. Download the `NotiArchive-debug-APK` artifact from the completed workflow.

The workflow locates the Gradle project directory, installs Android SDK Platform 35, builds `assembleDebug`, verifies the APK exists, and uploads it.

## First run

1. Install and launch NotiArchive.
2. Tap **Enable capture**.
3. Enable NotiArchive under Android's Notification access settings.
4. Return to the app. Newly posted notifications will be archived.

Android requires the user to explicitly grant notification-listener access. The app cannot silently enable it.

## Architecture

```text
Android NotificationManager
          |
          v
NotificationCaptureService
          |
          +--> package/keyword exclusion
          |
          v
ArchiveDb (SQLiteOpenHelper)
          |
          +--> notification table
          +--> notification_fts (FTS4)
          +--> insert/update/delete triggers
          |
          v
MainActivity
          |
          +--> searchable archive
          +--> notification details
          +--> retention settings
```

## Data and privacy

Archived notification content is stored in the app's private SQLite database on the device. Notifications can contain private messages, one-time codes and other sensitive information. Protect the device and review Android backup settings. The project does not request Internet permission and includes no analytics SDK.

## Scope

This is an independent implementation, not a binary-identical or source-identical rebuild of Samsung NotiStar. Samsung-only Good Lock integration, proprietary UI components, Secure Folder privileged access, cover-screen/AOD integrations and Samsung analytics are not included. Android permission and OEM behavior can vary by device.

Samsung and NotiStar are trademarks of their respective owners. No Samsung proprietary source code or signing keys are included.
