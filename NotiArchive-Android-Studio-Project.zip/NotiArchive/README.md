# NotiArchive

An independent Android notification-history application reconstructed from the observable architecture and feature set of Samsung NotiStar 7.0.17.0.

## Included

- Android `NotificationListenerService` capture.
- Local SQLite archive with insert/update behavior.
- SQLite FTS4 full-text index and triggers.
- FTS query with substring-search fallback.
- Package and keyword exclusion.
- Configurable retention (7/30/90/180/365 days or forever).
- Notification title, text, expanded text, package, timestamp, ongoing state, icon and picture storage.
- Searchable history and notification detail view.
- Manual deletion and clear-history action.

## Requirements

- Android Studio Ladybug or newer.
- JDK 17.
- Android SDK Platform 35.
- Android Gradle Plugin 8.7.3 (Gradle 8.9 compatible).

## Build

1. Open this directory in Android Studio.
2. Allow Gradle sync to complete.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Or from a machine with Gradle installed:

```bash
gradle assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## First run

1. Install and launch NotiArchive.
2. Tap **Enable capture**.
3. Enable NotiArchive under Android's Notification access settings.
4. Return to the app. Newly posted notifications will be archived.

Android requires the user to explicitly grant notification-listener access. The app cannot silently enable it.

## Architecture

```text
Android NotificationManager
          |
          v
NotificationCaptureService
          |
          +--> package/keyword exclusion
          |
          v
ArchiveDb (SQLiteOpenHelper)
          |
          +--> notification table
          +--> notification_fts (FTS4)
          +--> insert/update/delete triggers
          |
          v
MainActivity
          |
          +--> searchable archive
          +--> notification details
          +--> retention settings
```

## Differences from Samsung NotiStar

This is an independent implementation, not a binary-identical or source-identical rebuild. Samsung-only Good Lock integration, proprietary UI components, Secure Folder privileged access, cover-screen/AOD integrations, and Samsung analytics are not reproduced. Android permission and OEM behavior can vary by device.

## Data and privacy

All archived notification content is stored locally in the app's private SQLite database. Notification content can include private messages, one-time codes, and other sensitive information. Protect the device and use Android backup settings carefully. No network permission or analytics SDK is included in this project.

## License and attribution

Independent implementation. Samsung and NotiStar are trademarks of their respective owners. No Samsung proprietary source code or signing keys are included.
