package dev.bingle.notiarchive

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private lateinit var db: ArchiveDb
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = ArchiveDb(this)
        applyRetentionPolicy()
        buildUi()
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::db.isInitialized && ::list.isInitialized) render()
    }

    private fun applyRetentionPolicy() {
        val days = getSharedPreferences("archive", MODE_PRIVATE).getInt("retention_days", 90)
        if (days > 0) db.deleteOlderThan(System.currentTimeMillis() - days.toLong() * 86_400_000L)
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 12)
            setBackgroundColor(Color.rgb(18, 20, 25))
        }
        val header = TextView(this).apply {
            text = "NotiArchive"
            textSize = 27f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 6)
        }
        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.LTGRAY)
        }
        search = EditText(this).apply {
            hint = "Search notifications"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(39, 43, 51))
            setPadding(16, 10, 16, 10)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("Enable capture") { openListenerSettings() }, weightParams())
        actions.addView(actionButton("Filters") { showFilters() }, weightParams())
        actions.addView(actionButton("Settings") { showSettings() }, weightParams())

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        outer.addView(header)
        outer.addView(status)
        outer.addView(search, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 12; bottomMargin = 10 })
        outer.addView(actions)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, 48, 1f).apply {
        marginEnd = 5
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply { text = label; textSize = 11f; setOnClickListener { action() } }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val prefs = getSharedPreferences("filters", MODE_PRIVATE)
        val excluded = prefs.getStringSet("blocked_packages", emptySet()).orEmpty()
        val records = db.query(search.text?.toString().orEmpty(), excluded, 500)
        status.text = "${db.count()} archived · showing ${records.size}"
        if (records.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No notifications found. Enable notification access to start archiving."
                setTextColor(Color.LTGRAY)
                textSize = 15f
                setPadding(8, 28, 8, 28)
            })
        }
        records.forEach { record ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(Color.rgb(31, 35, 43))
            }
            val title = TextView(this).apply {
                text = record.title.ifBlank { record.packageName }
                textSize = 16f
                setTextColor(Color.WHITE)
            }
            val body = TextView(this).apply {
                text = listOf(record.content, record.bigText).filter { it.isNotBlank() }.distinct().joinToString("\n")
                textSize = 14f
                setTextColor(Color.LTGRAY)
            }
            val meta = TextView(this).apply {
                text = "${record.packageName}  ·  ${DateFormat.getDateTimeInstance().format(Date(record.postedAt))}"
                textSize = 11f
                setTextColor(Color.GRAY)
            }
            card.addView(title)
            if (body.text.isNotBlank()) card.addView(body)
            card.addView(meta)
            card.setOnClickListener { showRecord(record) }
            val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 }
            list.addView(card, params)
        }
    }

    private fun openListenerSettings() {
        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
    }

    private fun showFilters() {
        val prefs = getSharedPreferences("filters", MODE_PRIVATE)
        val input = EditText(this).apply {
            hint = "One blocked keyword per line"
            setText(prefs.getString("blocked_keywords", ""))
            minLines = 4
            gravity = Gravity.TOP
        }
        AlertDialog.Builder(this)
            .setTitle("Blocked keywords")
            .setMessage("Notifications containing any listed keyword in title, text, or expanded text will not be archived.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("blocked_keywords", input.text.toString()).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSettings() {
        val prefs = getSharedPreferences("archive", MODE_PRIVATE)
        val choices = arrayOf("7 days", "30 days", "90 days", "180 days", "365 days", "Forever")
        val values = intArrayOf(7, 30, 90, 180, 365, 0)
        val current = prefs.getInt("retention_days", 90)
        val selected = values.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("History retention")
            .setSingleChoiceItems(choices, selected) { dialog, which ->
                prefs.edit().putInt("retention_days", values[which]).apply()
                if (values[which] > 0) {
                    db.deleteOlderThan(System.currentTimeMillis() - values[which].toLong() * 86_400_000L)
                }
                dialog.dismiss()
                render()
            }
            .setNeutralButton("Clear history") { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle("Clear all history?")
                    .setMessage("This permanently deletes archived notifications.")
                    .setPositiveButton("Delete") { _, _ ->
                        db.writableDatabase.delete("notification", null, null)
                        render()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showRecord(record: NotificationRecord) {
        val text = buildString {
            append(record.packageName)
            append("\n")
            append(DateFormat.getDateTimeInstance().format(Date(record.postedAt)))
            append("\n\n")
            append(record.title)
            append("\n")
            append(record.content)
            if (record.bigText.isNotBlank()) append("\n\n").append(record.bigText)
            append("\n\nNotification ID: ").append(record.notificationId)
            append("\nKey: ").append(record.key)
        }
        AlertDialog.Builder(this)
            .setTitle("Notification details")
            .setMessage(text)
            .setPositiveButton("Close", null)
            .setNeutralButton("Delete") { _, _ ->
                db.deleteById(record.id)
                render()
            }
            .show()
    }
}
