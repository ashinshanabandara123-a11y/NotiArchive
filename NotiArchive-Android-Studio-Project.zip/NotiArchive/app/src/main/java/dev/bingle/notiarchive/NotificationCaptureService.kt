package dev.bingle.notiarchive

import android.app.Notification
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.Bundle
import android.util.Log
import java.io.ByteArrayOutputStream

class NotificationCaptureService : NotificationListenerService() {
    private val tag = "NotiArchiveCapture"
    private lateinit var db: ArchiveDb

    override fun onCreate() {
        super.onCreate()
        db = ArchiveDb(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            val n = sbn.notification ?: return
            val extras = n.extras ?: Bundle.EMPTY
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
            val picture = bitmapBytes(
                extras.get(Notification.EXTRA_PICTURE) as? Bitmap
            )
            val icon = try {
                val drawable = n.smallIcon?.loadDrawable(this)
                drawableBytes(drawable)
            } catch (_: Exception) { null }

            val record = NotificationRecord(
                id = 0L,
                key = sbn.key ?: "${sbn.packageName}:${sbn.id}:${sbn.postTime}",
                notificationId = sbn.id,
                packageName = sbn.packageName.orEmpty(),
                title = title,
                content = text,
                bigText = bigText,
                postedAt = sbn.postTime,
                ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0,
                icon = icon,
                picture = picture
            )
            if (!shouldBlock(record)) db.upsert(record)
        } catch (e: Exception) {
            Log.e(tag, "Unable to archive notification", e)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // Archived notifications intentionally remain in history after dismissal.
    }

    private fun shouldBlock(record: NotificationRecord): Boolean {
        val prefs = getSharedPreferences("filters", MODE_PRIVATE)
        val blockedPackages = prefs.getStringSet("blocked_packages", emptySet()).orEmpty()
        if (record.packageName in blockedPackages) return true
        val keywords = prefs.getString("blocked_keywords", "").orEmpty()
            .split("\\n").map { it.trim() }.filter { it.isNotEmpty() }
        val haystack = listOf(record.title, record.content, record.bigText)
        return keywords.any { keyword ->
            haystack.any { it.contains(keyword, ignoreCase = true) }
        }
    }

    private fun bitmapBytes(bitmap: Bitmap?): ByteArray? {
        if (bitmap == null) return null
        return try {
            ByteArrayOutputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
                out.toByteArray()
            }
        } catch (_: Exception) { null }
    }

    private fun drawableBytes(drawable: Drawable?): ByteArray? {
        val bitmap = (drawable as? BitmapDrawable)?.bitmap ?: return null
        return bitmapBytes(bitmap)
    }
}
