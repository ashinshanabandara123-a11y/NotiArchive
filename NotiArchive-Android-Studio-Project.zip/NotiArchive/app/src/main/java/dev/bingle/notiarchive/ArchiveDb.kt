package dev.bingle.notiarchive

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteException
import java.util.Locale

class ArchiveDb(context: Context) : SQLiteOpenHelper(
    context, "notiarchive.db", null, 1
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE notification (
                _id INTEGER PRIMARY KEY AUTOINCREMENT,
                notification_key TEXT NOT NULL UNIQUE,
                notification_id INTEGER NOT NULL DEFAULT 0,
                package_name TEXT NOT NULL,
                title TEXT NOT NULL DEFAULT '',
                content_text TEXT NOT NULL DEFAULT '',
                big_text TEXT NOT NULL DEFAULT '',
                posted_at INTEGER NOT NULL,
                ongoing INTEGER NOT NULL DEFAULT 0,
                icon BLOB,
                picture BLOB
            )"""
        )
        db.execSQL(
            """CREATE VIRTUAL TABLE notification_fts USING fts4(
                title, content_text, big_text, package_name,
                content='notification', tokenize=unicode61
            )"""
        )
        db.execSQL(
            """CREATE TRIGGER notification_ai AFTER INSERT ON notification BEGIN
                INSERT INTO notification_fts(docid,title,content_text,big_text,package_name)
                VALUES(new._id,new.title,new.content_text,new.big_text,new.package_name);
            END"""
        )
        db.execSQL(
            """CREATE TRIGGER notification_ad AFTER DELETE ON notification BEGIN
                DELETE FROM notification_fts WHERE docid=old._id;
            END"""
        )
        db.execSQL(
            """CREATE TRIGGER notification_au AFTER UPDATE ON notification BEGIN
                DELETE FROM notification_fts WHERE docid=old._id;
                INSERT INTO notification_fts(docid,title,content_text,big_text,package_name)
                VALUES(new._id,new.title,new.content_text,new.big_text,new.package_name);
            END"""
        )
        db.execSQL("CREATE INDEX notification_time_idx ON notification(posted_at DESC)")
        db.execSQL("CREATE INDEX notification_package_idx ON notification(package_name)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Versioned schema migrations belong here.
    }

    @Synchronized
    fun upsert(record: NotificationRecord) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("notification_key", record.key)
            put("notification_id", record.notificationId)
            put("package_name", record.packageName)
            put("title", record.title)
            put("content_text", record.content)
            put("big_text", record.bigText)
            put("posted_at", record.postedAt)
            put("ongoing", if (record.ongoing) 1 else 0)
            record.icon?.let { put("icon", it) }
            record.picture?.let { put("picture", it) }
        }
        db.insertWithOnConflict("notification", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun query(search: String = "", excludedPackages: Set<String> = emptySet(), limit: Int = 300): List<NotificationRecord> {
        val db = readableDatabase
        val excludedSql = if (excludedPackages.isEmpty()) "" else
            " AND n.package_name NOT IN (${excludedPackages.joinToString(",") { "?" }})"
        val args = mutableListOf<String>()
        var where = "1=1"
        if (search.isNotBlank()) {
            val tokens = search.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
            val ftsQuery = tokens.joinToString(" AND ") { token ->
                "\"" + token.replace("\"", "\"\"") + "\"*"
            }
            try {
                val ftsArgs = mutableListOf(ftsQuery).apply { addAll(excludedPackages) }
                val cursor = db.rawQuery(
                    "SELECT n._id,n.notification_key,n.notification_id,n.package_name,n.title,n.content_text,n.big_text,n.posted_at,n.ongoing,n.icon,n.picture " +
                    "FROM notification n JOIN notification_fts f ON f.docid=n._id " +
                    "WHERE notification_fts MATCH ?$excludedSql ORDER BY n.posted_at DESC LIMIT ?",
                    (ftsArgs + limit.toString()).toTypedArray()
                )
                return cursor.use { readRecords(it) }
            } catch (_: SQLiteException) {
                where += " AND (title LIKE ? OR content_text LIKE ? OR big_text LIKE ? OR package_name LIKE ?)"
                val like = "%$search%"
                args.addAll(listOf(like, like, like, like))
            }
        }
        args.addAll(excludedPackages)
        args.add(limit.toString())
        val cursor = db.rawQuery(
            "SELECT _id,notification_key,notification_id,package_name,title,content_text,big_text,posted_at,ongoing,icon,picture " +
            "FROM notification WHERE $where$excludedSql ORDER BY posted_at DESC LIMIT ?",
            args.toTypedArray()
        )
        return cursor.use { readRecords(it) }
    }

    fun deleteOlderThan(cutoffMillis: Long): Int =
        writableDatabase.delete("notification", "posted_at < ?", arrayOf(cutoffMillis.toString()))

    fun deleteById(id: Long): Int =
        writableDatabase.delete("notification", "_id=?", arrayOf(id.toString()))

    fun count(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM notification", null).use {
            return if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    private fun readRecords(c: Cursor): List<NotificationRecord> {
        val result = ArrayList<NotificationRecord>(c.count)
        while (c.moveToNext()) {
            result += NotificationRecord(
                id = c.getLong(0),
                key = c.getString(1) ?: "",
                notificationId = c.getInt(2),
                packageName = c.getString(3) ?: "",
                title = c.getString(4) ?: "",
                content = c.getString(5) ?: "",
                bigText = c.getString(6) ?: "",
                postedAt = c.getLong(7),
                ongoing = c.getInt(8) != 0,
                icon = if (c.isNull(9)) null else c.getBlob(9),
                picture = if (c.isNull(10)) null else c.getBlob(10)
            )
        }
        return result
    }
}
